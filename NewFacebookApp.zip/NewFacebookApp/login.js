// Name and Password from the register-form
// var name = document.getElementById('name');
// var pw = document.getElementById('pw');

// storing input from register-form
// function store() {
//     localStorage.setItem('name', name.value);
//     localStorage.setItem('pw', pw.value);
// }


function check() {

    var today = new Date();
    var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();   
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var datetime = date +' - '+time;
    // var storedName = localStorage.getItem('name1');
    // var storedPw = localStorage.getItem('pw');
    
    var userName = document.getElementById('userName').value;
    var userPw = document.getElementById('userPw').value;
    var getactivity=  JSON.parse(localStorage.getItem('ActivityLog'));
    if(getactivity == null){
        getactivity=[];
    }
    var datas={Title:'Login',Datetimes:datetime};

    var item = JSON.parse(localStorage.getItem('userDetails'));
    for (var i = 0; i < item.length; i++) {
        var object = item[i];
        
        if (object.username == userName && object.password == userPw) {
            getactivity.push(datas);
            localStorage.setItem('ActivityLog',JSON.stringify(getactivity));
            alert("Login Successfully");
            var query = "?var1=" + i;
            window.location.href="page2.html" + query;
        } 
        else {
        }
    }
}
    // if(userName.value !== storedName || userPw.value !== storedPw) {
    //     alert('ERROR');
    // }else {
    //     alert('You are loged in.');
    // }

//     if(userName.value == storedName && userPw.value == storedPw) {
//         alert('You are loged in.');
        
//     }else {
//         alert('Yor are logged in successfully');
//     }

// }